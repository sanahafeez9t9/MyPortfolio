"use client"

import { useState, useEffect } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, Phone, Linkedin, MapPin, Calendar, ExternalLink, Heart, Sparkles, Flower2, Code2 } from "lucide-react"
import {
  SiPython,
  SiJavascript,
  SiCplusplus,
  SiHtml5,
  SiCss3,
  SiMysql,
  SiCisco,
  SiGooglecolab,
  SiAndroidstudio,
  SiMongodb,
  SiExpress,
  SiAngular,
  SiNodedotjs,
  SiFigma,
  SiAdobexd,
} from "react-icons/si"
import { FaJava } from "react-icons/fa"

export default function Portfolio() {
  const [activeSection, setActiveSection] = useState("home")
  const { scrollYProgress } = useScroll()
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"])

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "about", "education", "experience", "projects", "skills", "contact"]
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50">
      {/* Floating Decorative Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-20 left-10 text-pink-300 opacity-60"
          animate={{ rotate: 360, y: [0, -20, 0] }}
          transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        >
          <Flower2 size={40} />
        </motion.div>
        <motion.div
          className="absolute top-40 right-20 text-purple-300 opacity-60"
          animate={{ rotate: -360, y: [0, 20, 0] }}
          transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        >
          <Sparkles size={30} />
        </motion.div>
        <motion.div
          className="absolute bottom-40 left-20 text-pink-400 opacity-60"
          animate={{ rotate: 360, x: [0, 10, 0] }}
          transition={{ duration: 12, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        >
          <Heart size={35} />
        </motion.div>
      </div>

      {/* Navigation */}
      <motion.nav
        className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-pink-100"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <motion.div
              className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
            >
              Sana Hafeez
            </motion.div>
            <div className="hidden md:flex space-x-8">
              {["home", "about", "education", "experience", "projects", "skills", "contact"].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`capitalize transition-colors ${
                    activeSection === section ? "text-pink-600 font-semibold" : "text-gray-600 hover:text-pink-500"
                  }`}
                >
                  {section}
                </button>
              ))}
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <motion.div style={{ y }} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-pink-100/50 to-purple-100/50" />
        </motion.div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
              <motion.h1
                className="text-5xl lg:text-7xl font-bold mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.8 }}
              >
                <span className="bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                  Hello, I'm
                </span>
                <br />
                <span className="text-gray-800">Sana Hafeez</span>
              </motion.h1>

              <motion.p
                className="text-xl text-gray-600 mb-8 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.8 }}
              >
                Software Engineering Student & Aspiring Developer
                <br />
                <span className="text-pink-600 font-semibold">Creating beautiful digital experiences</span>
              </motion.p>

              <motion.div
                className="flex flex-wrap gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.8 }}
              >
                <Button
                  onClick={() => scrollToSection("projects")}
                  className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white px-8 py-3 rounded-full"
                >
                  View My Work
                </Button>
                <Button
                  onClick={() => scrollToSection("contact")}
                  variant="outline"
                  className="border-pink-300 text-pink-600 hover:bg-pink-50 px-8 py-3 rounded-full"
                >
                  Get In Touch
                </Button>
              </motion.div>
            </motion.div>

            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              <div className="relative w-80 h-80 mx-auto">
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full opacity-20"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                />
                <motion.div
                  className="absolute inset-4 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full opacity-30"
                  animate={{ rotate: -360 }}
                  transition={{ duration: 15, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                />
                <div className="absolute inset-8 bg-white rounded-full shadow-2xl overflow-hidden">
                  <img src="/images/sana-avatar.jpg" alt="Sana Hafeez" className="w-full h-full object-cover" />
                </div>

                {/* Floating elements around profile */}
                <motion.div
                  className="absolute -top-4 -right-4 bg-pink-100 p-3 rounded-full shadow-lg"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                >
                  <Sparkles className="text-pink-500" size={24} />
                </motion.div>
                <motion.div
                  className="absolute -bottom-4 -left-4 bg-purple-100 p-3 rounded-full shadow-lg"
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY }}
                >
                  <Heart className="text-purple-500" size={24} />
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white/50">
        <div className="container mx-auto px-6">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              About Me
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full" />
          </motion.div>

          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                I'm a passionate Software Engineering student at the National University of Modern Languages, currently
                pursuing my Bachelor's degree. With a strong foundation in programming and a keen interest in creating
                innovative solutions, I'm dedicated to building beautiful and functional digital experiences.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                My journey in technology has been enriched by hands-on experience as a Software Engineer Intern at NTC
                Islamabad, where I worked on network infrastructure and gained valuable industry insights.
              </p>

              <div className="flex items-center justify-center gap-4 text-gray-600">
                <MapPin className="text-pink-500" size={20} />
                <span>Nawanshehr Tehsil & District Abbottabad, Pakistan</span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Education
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card className="max-w-4xl mx-auto border-0 shadow-2xl bg-gradient-to-br from-white to-pink-50">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-xl">NUML</span>
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-800">National University of Modern Languages</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                      Bachelor of Science in Software Engineering
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-pink-600">
                  <Calendar size={16} />
                  <span>Sep 2021 – May 2026</span>
                </div>
              </CardHeader>
              <CardContent>
                <h4 className="font-semibold text-gray-800 mb-4">Relevant Coursework:</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    "Data Structures and Algorithms",
                    "Operating System",
                    "Object Oriented Programming",
                    "DBMS",
                    "Internet Technology",
                    "AI",
                    "Software Methodology",
                    "Computer Architecture",
                    "Algorithm Analysis",
                  ].map((course, index) => (
                    <motion.div
                      key={course}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1, duration: 0.5 }}
                      viewport={{ once: true }}
                    >
                      <Badge
                        variant="secondary"
                        className="bg-pink-100 text-pink-700 hover:bg-pink-200 w-full justify-center py-2"
                      >
                        {course}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 bg-white/50">
        <div className="container mx-auto px-6">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Experience
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card className="max-w-4xl mx-auto border-0 shadow-2xl bg-gradient-to-br from-white to-purple-50">
              <CardHeader>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-xl">NTC</span>
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-800">Software Engineer Intern</CardTitle>
                    <CardDescription className="text-lg text-gray-600">NTC Islamabad</CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-purple-600">
                  <Calendar size={16} />
                  <span>June 2022 – August 2022</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-gray-700">
                      Assisted in configuring and maintaining routers, switches, and firewalls.
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-gray-700">
                      Monitored network performance and uptime using standard tools.
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-gray-700">Troubleshot LAN/WAN issues under senior supervision.</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Projects
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full" />
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-0 shadow-2xl bg-gradient-to-br from-white to-pink-50 hover:shadow-3xl transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl text-gray-800">Student Management System</CardTitle>
                    <ExternalLink className="text-pink-500" size={20} />
                  </div>
                  <CardDescription className="text-gray-600">Jan 2024</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">
                    Developed a comprehensive web application for managing student records with responsive UI for
                    registration, course assignments, and attendance tracking.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {["HTML", "CSS", "JavaScript", "Python"].map((tech) => (
                      <Badge key={tech} variant="outline" className="border-pink-300 text-pink-600">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-0 shadow-2xl bg-gradient-to-br from-white to-purple-50 hover:shadow-3xl transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl text-gray-800">WireGuard VPN System</CardTitle>
                    <ExternalLink className="text-purple-500" size={20} />
                  </div>
                  <CardDescription className="text-gray-600">Nov 2024</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">
                    Implemented a secure VPN solution using WireGuard with Python automation for tunnel configuration
                    and performance optimization.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {["Cisco", "Python", "WireGuard", "Networking"].map((tech) => (
                      <Badge key={tech} variant="outline" className="border-purple-300 text-purple-600">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Tech Stack Section */}
      <section id="skills" className="py-20 bg-white/50">
        <div className="container mx-auto px-6">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Tech Stack & Certifications
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full" />
          </motion.div>

          <div className="max-w-6xl mx-auto">
            {/* Tech Stack */}
            <div className="mb-16">
              <motion.div
                className="text-center mb-12"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
              >
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Technologies I Work With</h3>
                <p className="text-gray-600">My toolkit for building amazing digital experiences</p>
              </motion.div>

              <div className="grid lg:grid-cols-2 gap-8">
                <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                  viewport={{ once: true }}
                >
                  <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-pink-50 h-full">
                    <CardHeader>
                      <CardTitle className="text-xl text-gray-800 flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-500 rounded-lg flex items-center justify-center">
                          <span className="text-white text-sm font-bold">💻</span>
                        </div>
                        Programming Languages
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          { name: "Python", icon: SiPython, color: "from-blue-400 to-yellow-400" },
                          { name: "Java", icon: FaJava, color: "from-orange-400 to-red-500" },
                          { name: "C++", icon: SiCplusplus, color: "from-blue-400 to-purple-500" },
                          { name: "JavaScript", icon: SiJavascript, color: "from-yellow-300 to-orange-400" },
                          { name: "HTML", icon: SiHtml5, color: "from-orange-400 to-red-400" },
                          { name: "CSS", icon: SiCss3, color: "from-blue-400 to-blue-600" },
                          { name: "SQL", icon: SiMysql, color: "from-blue-500 to-orange-400" },
                        ].map((lang, index) => (
                          <motion.div
                            key={lang.name}
                            className="bg-white rounded-xl p-4 shadow-lg hover:shadow-xl transition-all duration-300 border border-pink-100"
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            transition={{ delay: index * 0.1, duration: 0.5 }}
                            viewport={{ once: true }}
                            whileHover={{ scale: 1.05, y: -5 }}
                          >
                            <div className="text-center">
                              <lang.icon className="text-3xl mb-2 mx-auto" style={{ color: "currentColor" }} />
                              <div
                                className={`text-sm font-semibold bg-gradient-to-r ${lang.color} bg-clip-text text-transparent`}
                              >
                                {lang.name}
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                  viewport={{ once: true }}
                >
                  <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-purple-50 h-full">
                    <CardHeader>
                      <CardTitle className="text-xl text-gray-800 flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                          <span className="text-white text-sm font-bold">🛠️</span>
                        </div>
                        Developer Tools
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          { name: "VS Code", icon: Code2, color: "from-blue-400 to-blue-600" },
                          { name: "Cisco Packet Tracer", icon: SiCisco, color: "from-blue-500 to-teal-500" },
                          { name: "Google Colab", icon: SiGooglecolab, color: "from-orange-400 to-yellow-500" },
                          { name: "Android Studio", icon: SiAndroidstudio, color: "from-green-500 to-lime-500" },
                        ].map((tool, index) => (
                          <motion.div
                            key={tool.name}
                            className="bg-white rounded-xl p-4 shadow-lg hover:shadow-xl transition-all duration-300 border border-purple-100"
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            transition={{ delay: index * 0.1, duration: 0.5 }}
                            viewport={{ once: true }}
                            whileHover={{ scale: 1.05, y: -5 }}
                          >
                            <div className="text-center">
                              <tool.icon className="text-3xl mb-2 mx-auto" style={{ color: "currentColor" }} />
                              <div
                                className={`text-sm font-semibold bg-gradient-to-r ${tool.color} bg-clip-text text-transparent`}
                              >
                                {tool.name}
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </div>

            {/* Certifications */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Certifications</h3>
                <p className="text-gray-600">Professional development and specialized training</p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-pink-50">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">M</span>
                      </div>
                      <CardTitle className="text-lg text-gray-800">MEAN Stack Development</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Built full-stack applications using MongoDB, Express.js, Angular, and Node.js. Learned RESTful API
                      design, NoSQL databases, and front-end/backend integration.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge className="bg-pink-100 text-pink-700 hover:bg-pink-200 flex items-center gap-1">
                        <SiMongodb className="w-3 h-3" />
                        MongoDB
                      </Badge>
                      <Badge className="bg-pink-100 text-pink-700 hover:bg-pink-200 flex items-center gap-1">
                        <SiExpress className="w-3 h-3" />
                        Express.js
                      </Badge>
                      <Badge className="bg-pink-100 text-pink-700 hover:bg-pink-200 flex items-center gap-1">
                        <SiAngular className="w-3 h-3" />
                        Angular
                      </Badge>
                      <Badge className="bg-pink-100 text-pink-700 hover:bg-pink-200 flex items-center gap-1">
                        <SiNodedotjs className="w-3 h-3" />
                        Node.js
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-purple-50">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">UI</span>
                      </div>
                      <CardTitle className="text-lg text-gray-800">UI/UX Design</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Studied user-centered design principles, usability testing, and modern design trends. Created
                      wireframes and interactive prototypes using industry-standard tools.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200 flex items-center gap-1">
                        <SiFigma className="w-3 h-3" />
                        Figma
                      </Badge>
                      <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200 flex items-center gap-1">
                        <SiAdobexd className="w-3 h-3" />
                        Adobe XD
                      </Badge>
                      <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200">Prototyping</Badge>
                      <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200">User Research</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Let's Connect
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full" />
            <p className="text-gray-600 mt-6 max-w-2xl mx-auto">
              I'm always excited to discuss new opportunities and collaborate on interesting projects. Feel free to
              reach out!
            </p>
          </motion.div>

          <motion.div
            className="max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-pink-50">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-3 gap-8">
                  <motion.div className="text-center" whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
                    <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Phone className="text-white" size={24} />
                    </div>
                    <h3 className="font-semibold text-gray-800 mb-2">Phone</h3>
                    <p className="text-gray-600">+92 314 3707610</p>
                  </motion.div>

                  <motion.div className="text-center" whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Mail className="text-white" size={24} />
                    </div>
                    <h3 className="font-semibold text-gray-800 mb-2">Email</h3>
                    <p className="text-gray-600">sanahafeez8oct@gmail.com</p>
                  </motion.div>

                  <motion.div className="text-center" whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
                    <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Linkedin className="text-white" size={24} />
                    </div>
                    <h3 className="font-semibold text-gray-800 mb-2">LinkedIn</h3>
                    <p className="text-gray-600">linkedin.com/in/sanahafeez</p>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gradient-to-r from-pink-600 to-purple-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            © 2024 Sana Hafeez. Made with <Heart className="inline w-4 h-4 text-pink-200" /> and lots of code.
          </motion.p>
        </div>
      </footer>
    </div>
  )
}
